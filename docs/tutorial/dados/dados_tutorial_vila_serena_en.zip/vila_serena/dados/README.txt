Vila Serena - tutorial data for Vista Saga Plugin 1.6.0

Fictitious town; all data are synthetic and free to use.
CRS: SIRGAS 2000 / UTM 25S (EPSG:31985). Rasters: 200 x 200 cells of 10 m.

uso_solo_2000/2010/2020.tif    land use: 1 Urban area, 2 Native vegetation, 3 Farming, 4 Pasture, 5 Water
solos.tif                      soils: 1 Argisol, 2 Latosol, 3 Fluvic neosol
declividade.tif                slope: 1 Flat, 2 Gently rolling, 3 Rolling, 4 Strongly rolling
atrito.tif                     friction rating (urban 1, pasture/farming 2, vegetation 4, water 10)
bairros.gpkg                   6 districts (CODIGO, NOME)
escolas.gpkg                   6 schools (NOME, MATRICULAS = enrolment)
aptidao_expansao.geosaga.json  Evaluation project (Open project...)

Keep the .aux.xml files next to the .tif files: they hold the class names.
